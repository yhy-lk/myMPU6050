#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"
#include "Timer.h"
#include "MadgwickAHRS.h"

uint64_t millis;                        //millis为当前程序运行的时间，类似arduino里millis()函数

uint8_t ID;								//定义用于存放ID号的变量
int16_t AX, AY, AZ, GX, GY, GZ;			//定义用于存放各个数据的变量

MPU6050Params mpu6050 = {
    .MPU6050dt = 10,
    .preMillis = 0,
    .MPU6050ERROE = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f}
};

SensorMsg msg = {
	.A = {0.0f, 0.0f, 0.0f},
	.G = {0.0f, 0.0f, 0.0f}
};

void MPU6050Print() {
	OLED_ShowSignedNum(2, 1, msg.A[0], 3);					  //OLED显示数据
	OLED_ShowNum(2, 6, (uint32_t)(msg.A[0] * 100) % 100, 1);			
	OLED_ShowSignedNum(3, 1, msg.A[1], 3);
	OLED_ShowNum(3, 6, (uint32_t)(msg.A[1] * 100) % 100, 1);
	OLED_ShowSignedNum(4, 1, msg.A[2], 3);
	OLED_ShowNum(4, 6, (uint32_t)(msg.A[2] * 100) % 100, 1);
	OLED_ShowSignedNum(2, 8, msg.G[0], 3);
	OLED_ShowNum(2, 13, (uint32_t)(msg.G[0] * 100) % 100, 1);
	OLED_ShowSignedNum(3, 8, msg.G[1], 3);
	OLED_ShowNum(3, 13, (uint32_t)(msg.G[1] * 100) % 100, 1);
	OLED_ShowSignedNum(4, 8, msg.G[2], 3);
	OLED_ShowNum(4, 13, (uint32_t)(msg.G[2] * 100) % 100, 1);
}

void EularPrint() {
	OLED_ShowString(2, 1, "Yaw:");
	OLED_ShowSignedNum(2, 8, getYaw(), 3);
	OLED_ShowNum(2, 13, (uint32_t)(getYaw() * 100) % 100, 2);			
	OLED_ShowString(3, 1, "Roll:");
	OLED_ShowSignedNum(3, 8, getRoll(), 3);
	OLED_ShowNum(3, 13, (uint32_t)(getRoll() * 100) % 100, 2);			
	OLED_ShowString(4, 1, "Pitch:");
	OLED_ShowSignedNum(4, 8, getPitch(), 3);
	OLED_ShowNum(4, 13, (uint32_t)(getPitch() * 100) % 100, 2);			
}

int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	begin(1000.0f / (float)mpu6050.MPU6050dt);

	MPU6050_Init();		//MPU6050初始化
	Timer_Init();		//定时中断初始化
	
	dataGetERROR();


	OLED_ShowString(2, 1, "        000.0");		//显示静态字符串
	OLED_ShowString(3, 1, "        000.0");		//显示静态字符串
	OLED_ShowString(4, 1, "        000.0");		//显示静态字符串

	while (1)
	{
		OLED_ShowNum(1, 1, millis, 7);
		if(millis - mpu6050.preMillis >= mpu6050.MPU6050dt) {
			mpu6050.preMillis = millis;
			dataGetAndFilter();		                            //获取MPU6050的数据
			updateIMU(msg.G[0], msg.G[1], msg.G[2], msg.A[0], msg.A[1], msg.A[2]);
		}
	
		EularPrint();
	}	


}


void dataGetERROR() {
	for(uint8_t i = 0; i < 100; ++i) {
		getMPU6050Data();
		mpu6050.MPU6050ERROE[0] += msg.A[0];
		mpu6050.MPU6050ERROE[1] += msg.A[1];
		mpu6050.MPU6050ERROE[2] += msg.A[2] - 9.8;
		mpu6050.MPU6050ERROE[3] += msg.G[0];
		mpu6050.MPU6050ERROE[4] += msg.G[1];
		mpu6050.MPU6050ERROE[5] += msg.G[2];
		Delay_ms(10);
	}
	for(uint8_t i = 0; i < 6; ++i) {
		mpu6050.MPU6050ERROE[i] /= 100.0f;
	}
}


void getMPU6050Data() {
	MPU6050_GetData(&AX, &AY, &AZ, &GX, &GY, &GZ);		//获取MPU6050的数据
	msg.A[0] = (float)((float)AX / (float)32768) * 16 * 9.8;
	msg.A[1] = (float)((float)AY / (float)32768) * 16 * 9.8;
	msg.A[2] = (float)((float)AZ / (float)32768) * 16 * 9.8;
	msg.G[0] = (float)((float)GX / (float)32768) * 2000 * 3.5;
	msg.G[1] = (float)((float)GY / (float)32768) * 2000 * 3.5;
	msg.G[2] = (float)((float)GZ / (float)32768) * 2000 * 3.5;
	
}

void dataGetAndFilter() {
	getMPU6050Data();
	msg.A[0] -= mpu6050.MPU6050ERROE[0];
	msg.A[1] -= mpu6050.MPU6050ERROE[1];
	msg.A[2] -= mpu6050.MPU6050ERROE[2];
	msg.G[0] -= mpu6050.MPU6050ERROE[3];
	msg.G[1] -= mpu6050.MPU6050ERROE[4];
	msg.G[2] -= mpu6050.MPU6050ERROE[5];
}

void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)		//判断是否是TIM2的更新事件触发的中断
	{
		millis++;											
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);			//清除TIM2更新事件的中断标志位
															//中断标志位必须清除
															//否则中断将连续不断地触发，导致主程序卡死
	}
}
